pico-launcher Direct ROM Launch - Drag & Drop Setup
===================================================

This ZIP is ONLY the folder structure + config + handoff files.
It does NOT include a modified pico-launcher binary.
You still need a pico-launcher build that implements:
  - parsing emulators.ini
  - method=argv support
  - method=pathfile support

Where to extract:
  - Extract the contents of this ZIP onto the ROOT of your SD card.
  - It will merge into:
      sd:/_nds/pico-launcher/

Files you get:
  sd:/_nds/pico-launcher/emulators.ini
    - Routing rules (ROM extension -> emulator -> method)
  sd:/_nds/pico-launcher/handoff/
    - Where pico-launcher writes ROM paths for method=pathfile
  sd:/_nds/pico-launcher/docs/README-SETUP.txt
    - This file
  sd:/_nds/pico-launcher/examples/
    - Example ROM folder layouts + notes

IMPORTANT: Fix emulator paths
----------------------------
The emulators.ini template points to:
  sd:/_nds/TWiLightMenu/emulators/<emu>.nds

If you keep your emulators elsewhere (example: sd:/Emulators/),
edit the 'emu =' lines to match your SD layout.

Path prefixes (sd:/ vs /):
--------------------------
Some builds use 'sd:/' (devkitPro style), others use '/'
for SD root. If your build expects '/', change both the emu
and pathfile lines accordingly, like:

  emu = /_nds/TWiLightMenu/emulators/gameyob.nds
  pathfile = /_nds/pico-launcher/handoff/lastrom_snes.txt

How to add a system:
--------------------
Add a new block:

  [MY_SYSTEM]
  ext = ext1,ext2
  emu = sd:/path/to/emulator.nds
  method = argv

OR for pathfile:

  [MY_SYSTEM]
  ext = ext1,ext2
  emu = sd:/path/to/emulator.nds
  method = pathfile
  pathfile = sd:/_nds/pico-launcher/handoff/lastrom_mysystem.txt

Troubleshooting:
----------------
- If an emulator ignores the ROM and opens its menu:
    * Switch that system's method to pathfile (if emulator supports it), OR
    * Use / patch an emulator build that supports argv or pathfile.
- If nothing launches:
    * Confirm the 'emu =' path is correct.
    * Confirm pico-launcher can access that filesystem location.
    * Confirm your SD is not read-only/corrupt.

Handoff file format:
--------------------
The default is a plain text file containing ONE line:
  <full rom path>

Example:
  sd:/roms/snes/Super Metroid.sfc

If your emulator expects a different format, adjust pico-launcher's writer
OR point 'pathfile=' to the exact file the emulator expects.
