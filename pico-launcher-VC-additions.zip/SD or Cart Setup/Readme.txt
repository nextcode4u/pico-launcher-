Copy the folder contents of the setup that matches your environment to the root of your SD/flashcart.
